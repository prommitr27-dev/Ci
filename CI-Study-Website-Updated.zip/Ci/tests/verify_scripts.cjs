// Exercise the actual inline scripts in a minimal DOM harness. This is not a browser/layout test.
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
for (const s of scripts) new vm.Script(s);
function element() {
  const classes = new Set(), handlers = {};
  return {value: '', textContent: '', innerHTML: '', children: [], open: false, handlers, style:{},
    classList: {add: c => classes.add(c), remove: c => classes.delete(c), contains: c => classes.has(c), toggle(c, force) {
      if (force === true || force === undefined && !classes.has(c)) {classes.add(c); return true;}
      classes.delete(c); return false;
    }},
    addEventListener: (name, fn) => handlers[name] = fn,
    focus() {this.focused = true;}, append(...items) {this.children.push(...items);}, appendChild(item) {this.children.push(item);}, replaceChildren() {this.children = [];}
  };
}
const ids = new Map();
const el = id => {if (!ids.has(id)) ids.set(id, element()); return ids.get(id);};
for (const m of html.matchAll(/<input\b[^>]*>/g)) {
  const id = m[0].match(/id=["']([^"']+)/)?.[1];
  if (id) el(id).value = m[0].match(/value=["']([^"']*)/)?.[1] ?? '';
}
const store = new Map(), styles = new Map(), events = {};
const lesson = {id:'test-lesson', textContent:'x'.repeat(12000) + ' ค้นหาปลายบทได้', querySelector: () => ({textContent: 'หัวข้อทดสอบ'})};
const link = element();link.getAttribute = () => '#test-lesson';
const detail = element();
const document = {getElementById: el, body: element(),
  documentElement: {scrollHeight: 3000, style:{setProperty: (k,v) => styles.set(k,v)}},
  querySelectorAll: selector => selector === '.lesson' ? [lesson] : selector === '.navitem' ? [link] : selector === 'details.exercise' ? [detail] : [],
  createElement: element};
const context = vm.createContext({document, window:{addEventListener:(k,v)=>events[k]=v, print:()=>{}},
  localStorage:{getItem:k=>store.get(k),setItem:(k,v)=>store.set(k,String(v))},
  IntersectionObserver: class {observe() {}}, scrollY: 0, innerHeight: 900, Math, Number, Set, console});
for (const script of scripts) vm.runInContext(script,context);
assert.match(el('pso-calc-out').innerHTML, /-4\.5/);
function inputs(data) {for (const [id,v] of Object.entries(data)) el(id).value = String(v);}
inputs({'pso-x':4,'pso-v':-1,'pso-p':2,'pso-g':1,'pso-r1':1,'pso-r2':.5});
el('pso-x').handlers.input();
assert.match(el('pso-calc-out').innerHTML, /<b>-4\.5<\/b>/);
assert.match(el('pso-calc-out').innerHTML, /<b>-0\.5<\/b>/);
el('pso-x').value='';el('pso-x').handlers.input();
assert.match(el('pso-calc-out').textContent,/กรุณา/);
inputs({'pso-x':0,'pso-v':0,'pso-p':0,'pso-g':0,'pso-r1':0,'pso-r2':0});
el('pso-x').handlers.input();assert.match(el('pso-calc-out').innerHTML,/<b>0<\/b>/);
inputs({'aco-t1':2,'aco-d1':10,'aco-t2':1,'aco-d2':5,'aco-a':1,'aco-b':1});
el('aco-t1').handlers.input();assert.match(el('aco-calc-out').innerHTML,/P₁ = 50%/);assert.match(el('aco-calc-out').innerHTML,/P₂ = 50%/);
el('aco-d1').value='0';el('aco-d1').handlers.input();assert.match(el('aco-calc-out').textContent,/กรุณา/);
el('aco-d1').value='';el('aco-d1').handlers.input();assert.match(el('aco-calc-out').textContent,/กรุณา/);
inputs({'aco-d1':10,'aco-t1':0,'aco-t2':0});el('aco-t1').handlers.input();assert.match(el('aco-calc-out').textContent,/น้ำหนักรวม/);
inputs({'aco-t1':.5,'aco-d1':75,'aco-t2':.5,'aco-d2':20});el('aco-t1').handlers.input();
assert.match(el('aco-calc-out').innerHTML,/P₁ = 21\.05263%/);
el('theme').onclick();assert.equal(document.body.classList.contains('dark'),true);assert.equal(store.get('cifinal-dark'),'1');
el('theme').onclick();assert.equal(document.body.classList.contains('dark'),false);
el('larger').onclick();assert.equal(styles.get('--fontsize'),'17px');el('smaller').onclick();assert.equal(styles.get('--fontsize'),'16px');
el('menu').onclick();assert.equal(el('sidebar').classList.contains('open'),true);link.handlers.click();assert.equal(el('sidebar').classList.contains('open'),false);
el('searchbtn').onclick();el('searchinput').value='ค้นหาปลายบทได้';el('searchinput').handlers.input();assert.equal(el('searchresults').children.length,1);
el('closesearch').onclick();assert.equal(el('searchoverlay').classList.contains('open'),false);
events.beforeprint();assert.equal(detail.open,true);events.afterprint();assert.equal(detail.open,false);
console.log(JSON.stringify({result:'PASS',scripts:scripts.length,checks:['JavaScript syntax','PSO example and zero values','PSO blank rejection','ACO equal probabilities','ACO invalid input and zero-weight rejection','two-route ACO recalculation','theme persistence','font size','mobile menu callbacks','search past 12000 characters','print answers and restore state'],limitation:'Minimal DOM harness; browser rendering, responsive layout and print preview not verified'},null,2));
