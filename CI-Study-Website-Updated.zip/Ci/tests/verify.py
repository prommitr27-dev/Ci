"""Check the delivered reader's links, source tables and independently recomputed answers."""
from pathlib import Path
from html.parser import HTMLParser
from fractions import Fraction as F
import collections, json, math, re, hashlib

ROOT=Path(__file__).resolve().parents[1]
class Reader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids=[];self.links=[];self.images=[];self.tables=[];self.table=None;self.row=None;self.cell=None;self.caption=False
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        if tag=='a':self.links.append(a.get('href',''))
        if tag=='img':self.images.append(a)
        if tag=='table':self.table={'caption':'','rows':[]}
        if tag=='caption':self.caption=True
        if tag=='tr':self.row=[]
        if tag in ('td','th'):self.cell=''
    def handle_data(self,data):
        if self.cell is not None:self.cell+=data
        if self.caption and self.table is not None:self.table['caption']+=data
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.row is not None:
            self.row.append(self.cell.strip());self.cell=None
        if tag=='tr' and self.table is not None:
            self.table['rows'].append(self.row);self.row=None
        if tag=='caption':self.caption=False
        if tag=='table':self.tables.append(self.table);self.table=None

def run():
    source=(ROOT/'index.html').read_text(encoding='utf-8')
    d=Reader();d.feed(source)
    duplicate=[v for v,n in collections.Counter(d.ids).items() if n>1]
    assert not duplicate,('Duplicate IDs',duplicate)
    missing=[h for h in d.links if h.startswith('#') and h[1:] not in d.ids]
    assert not missing,('Broken anchors',missing)
    for im in d.images:
        assert im.get('alt','').strip(),('Missing alt',im)
        assert (ROOT/im['src']).is_file(),('Missing image',im)
    for h in d.links:
        if h and not h.startswith(('#','http:','https:','mailto:')):
            assert (ROOT/h).is_file(),('Missing local link',h)
    for n in range(1,17):assert f'worked-{n:02}' in d.ids,('Original example lost',n)
    for id in ['searchbtn','searchinput','theme','print','menu','pso-x','pso-v','pso-p','pso-g','pso-r1','pso-r2','pso-calc-out','aco-calc-out']:
        assert id in d.ids,('Original feature lost',id)
    assert not re.search(r'(?:src|href)=["\x27](?:https?://|//)',source), 'Unexpected external dependency'
    def t(prefix):
        return next(v['rows'] for v in d.tables if v and v['caption'].startswith(prefix))
    assert t('ตารางที่ 4.1')[1][:3]==['A','00000110','2']
    assert t('ตารางที่ 4.3')[3][:3]==['E′','10110000','3']
    for row in t('ตารางที่ 4.1')[1:]:assert row[1].count('1')==int(row[2])
    for row in t('ตารางที่ 4.3')[1:]:assert row[1].count('1')==int(row[2])
    roulette=t('ตาราง 4.4 ขยาย')[1:]
    total=0
    for row in roulette:
        x=int(row[1],2);f=x*x;total+=f
        assert x==int(row[2]) and f==int(row[3])
        assert math.isclose(float(row[4].split('=')[1]),f/1170,abs_tol=0.00000051)
    assert total==1170 and sum(int(r[7]) for r in roulette)==4
    p=[F(int(row[3]),1170) for row in roulette]; q=[sum(p[:i+1]) for i in range(4)]
    picks=[next(i+1 for i,lim in enumerate(q) if r<lim) for r in map(F,['.8','.5','.1','.6'])]
    assert picks==[4,2,1,2]
    children=t('ตารางที่ 4.5')[1:]
    for row in children:
        assert int(row[4],2)==int(row[5]) and int(row[5])**2==int(row[6])
    assert sum(int(row[6]) for row in children)==1754
    # Exact rational arithmetic avoids ambiguous floating point at the two SUS boundaries.
    def sus(n):
        q=[sum(n[:i+1]) for i in range(3)]
        return [next(i+1 for i,x in enumerate(q) if x>ptr) for ptr in [F(4,5),F(9,5),F(14,5)]]
    assert sus([F('.81'),F('.99'),F('1.2')])==[1,3,3]
    assert sus([F('.8'),F('1'),F('1.2')])==[2,3,3]
    assert t('ตาราง 4.6:')[1][3:]==['0.27','0.81','4/15=0.266666…','0.8']
    # Real-coded GA retains both the printed typo and a separately checked answer.
    real=t('ตาราง 4.7')[1:]
    assert real[1][3]=='0.007'
    for row in real:
        answer=1/(1+float(row[1])**2+float(row[2])**2)
        assert math.isclose(float(row[5]),answer,abs_tol=.00000051)
    gp=t('ประเมินครบทั้ง6เคส')[1:];hits=[0,0,0]
    for row in gp:
        A,P=map(float,row[:2]);outs=[A,A*(A*A-math.sqrt(A)),A+math.sqrt(A)*A]
        for i,(v,cell) in enumerate(zip(outs,row[2:])):
            printed=cell.split(' / ')
            err=abs(P-v)/abs(P)*100;hit=err<=20;hits[i]+=hit
            assert math.isclose(float(printed[0]),v,abs_tol=.00000051)
            assert math.isclose(float(printed[1].rstrip('%')),err,abs_tol=.000051)
            assert (printed[2]=='ผ่าน')==hit
    assert hits==[3,1,0]
    aco=t('ขยายตารางคำนวณจากตัวอย่าง5.3')[1:]
    distances=[75,150,20];w=[F(1,2)/dd for dd in distances];pr=[v/sum(w) for v in w]
    assert pr==[F(4,21),F(2,21),F(5,7)]
    for row,v in zip(aco,pr):assert math.isclose(float(row[5].rstrip('%')),float(v)*100,abs_tol=.000051)
    assert '4+10=14' in source and 'ไม่มีพิกัดpbestเดิม' in source
    assert '0.6,0' in source and '1/1.36=0.735294' in source
    assert '=(1.25,2.25)' in source and '=(1.15,1.95)' in source
    graph=t('ระยะทางจากกราฟเดิม')
    assert graph[1]==['1','—','100','75','50']
    assert graph[2]==['2','100','—','150','200']
    # Added practice is labeled; pending slides are not described as available.
    registry=json.loads((ROOT/'content/sources.json').read_text(encoding='utf-8'))
    assert registry['combinedSlides']['status']=='pending-upload'
    assert [r['pageCount'] for r in registry['sources']]==[69,65]
    assert len(registry['lessons'])==16
    for r in registry['sources']:assert re.fullmatch('[0-9a-f]{64}',r['sha256'])
    report={'result':'PASS','htmlIds':len(d.ids),'tables':len(d.tables),'sourceImages':len(d.images),'originalWorkedExamples':16,'newLessons':16,'checks':['local anchors and images','retained reader controls','bit-count tables','Roulette exact values and sampling','generation children and sums','SUS rounded versus exact boundaries','real-GA source typo and correction','GP six cases and 3/1/0 hits','ACO original graph probabilities','PSO missing pbest explicitly identified','slide source status']}
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return report

if __name__=='__main__':run()
