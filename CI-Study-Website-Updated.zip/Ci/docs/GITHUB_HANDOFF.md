# สถานะ GitHub และขั้นตอนที่เหลือ

ตรวจวันที่ 29 ตุลาคม 2026: repository `prommitr27-dev/Ci` ยังว่าง ไม่มี branch; บัญชีที่เชื่อมต่ออ่าน metadata ได้ แต่การสร้าง README ผ่าน Contents API ถูกปฏิเสธด้วย `403 Resource not accessible by integration` หลังลองเขียน ตรวจ branches ซ้ำแล้วยังเป็นรายการว่าง จึงยังไม่ได้ push และยังไม่ได้ deploy

## สิทธิ์ที่ต้องอนุญาต

การเชื่อมต่อที่ใช้เขียนต้องได้รับสิทธิ์เข้าถึง repository `prommitr27-dev/Ci` และสิทธิ์ **Contents (write)** ตาม [GitHub Contents API](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents) ถ้าสิทธิ์ของแอปเดิมไม่มีการเขียน ต้องให้ผู้ใช้อนุมัติสิทธิ์ที่รองรับการเขียนหรือใช้ GitHub CLI ที่เข้าสู่ระบบด้วยบัญชีที่ push ได้ ไม่ต้องส่ง token หรือรหัสผ่านเข้ามาในแชท

## วิธีบนเครื่องนี้: อนุญาตแล้วส่ง commit เดิม

GitHub CLI มีอยู่แล้ว แต่ตรวจ `gh auth status` พบว่าการเข้าสู่ระบบเดิมของ prommitr27-dev ใช้ไม่ได้ ผู้ใช้ต้องทำขั้นเข้าสู่ระบบเอง:

```powershell
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git --hostname github.com
```

เลือกบัญชี prommitr27-dev หรือบัญชีที่มีสิทธิ์เขียน Ci เมื่อเสร็จให้กลับมาแจ้งในแชทเพื่อส่ง commit ที่เตรียมไว้ ไม่จำเป็นต้องสร้างเว็บซ้ำ ไม่มีการขอให้เปลี่ยนสิทธิ์เผยแพร่หรือเปิด GitHub Pages อัตโนมัติ

ถ้าจะ push เอง ให้อยู่ในโฟลเดอร์ checkout นี้แล้วตรวจปลายทางและสถานะก่อน:

```powershell
git remote -v
git status
git push -u origin main
git ls-remote origin refs/heads/main
```

ปลายทางต้องเป็น `https://github.com/prommitr27-dev/Ci.git` และค่า SHA ที่ `ls-remote` คืนต้องตรงกับ `git rev-parse HEAD` จึงยืนยันว่า push สำเร็จ ถ้าปลายทางมีการเพิ่มไฟล์ภายหลัง ให้ดึงและตรวจความแตกต่างก่อน ห้าม force push

## บนคอมอีกเครื่อง

- สำหรับอ่าน: แตก ZIP ทั้งโฟลเดอร์ เปิด `Ci/index.html` และเก็บ `assets/` ไว้คู่กัน ใช้ได้โดยไม่ต้องเข้าสู่ระบบ
- สำหรับส่ง commit เดิม: ใช้ไฟล์ `.bundle` ที่ส่งให้คู่กับ ZIP เพื่อกู้ checkout พร้อมประวัติ แล้วตั้ง remote ไป GitHub และเข้าสู่ระบบ:

```powershell
git clone CI-Study-Website-Updated.bundle Ci
cd Ci
git remote set-url origin https://github.com/prommitr27-dev/Ci.git
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git --hostname github.com
git push -u origin main
```

Push เป็นการเก็บ source บน GitHub ไม่ใช่หลักฐานว่า GitHub Pages เปิดเว็บออนไลน์แล้ว งานรอบนี้ไม่มีผล deployment ที่ยืนยันได้
